import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from '@/ui-forge/ui/toaster';
import { Providers } from './providers';

export const metadata: Metadata = {
  title: 'ML Ascent - Aprendizado Interativo de Machine Learning',
  description: 'Domine Machine Learning através de visualizações interativas e sandboxes práticos.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Space+Grotesk:wght@500;700&family=Source+Code+Pro:wght@400;600&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground">
        <Providers>
          {children}
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
